let car = null;
console.log(typeof car);   // "object"
