let octalNum3 = 0o70;  // octal for 56
let octalNum4 = 0o79;  // invalid octal – SyntaxError
