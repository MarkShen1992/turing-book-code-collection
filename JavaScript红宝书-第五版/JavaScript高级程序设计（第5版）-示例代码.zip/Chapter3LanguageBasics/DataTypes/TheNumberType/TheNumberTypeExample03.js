let octalNum1 = 070;   // octal for 56
let octalNum2 = 079;   // invalid octal - interpreted as 79
let octalNum3 = 08;   // invalid octal - interpreted as 8
