let binaryNum1 = 0b110;  // binary for 6
let binaryNum2 = 0b333;  // invalid binary - SyntaxError
