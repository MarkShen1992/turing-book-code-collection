let intNum = 55;  // integer
