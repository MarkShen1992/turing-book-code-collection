let hexNum1 = 0xA;   // hexadecimal for 10
let hexNum2 = 0x1f;  // hexadecimal for 31
