let bigintA = 12345n;
let bigintB = BigInt(12345);
let bigintC = BigInt(0x12345);
let bigintD = BigInt("12345");
let bigintE = BigInt("0o12345"); 
