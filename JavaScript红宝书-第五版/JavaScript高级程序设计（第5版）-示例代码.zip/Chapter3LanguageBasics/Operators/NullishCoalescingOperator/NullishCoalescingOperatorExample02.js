variable = expression !== null && expression !== undefined ? expression : nullish_fallback_value;
