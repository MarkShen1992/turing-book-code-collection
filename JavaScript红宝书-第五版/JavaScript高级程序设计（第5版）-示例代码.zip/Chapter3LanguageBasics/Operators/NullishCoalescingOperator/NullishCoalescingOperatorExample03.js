const values = [null, undefined, 0, ""];

