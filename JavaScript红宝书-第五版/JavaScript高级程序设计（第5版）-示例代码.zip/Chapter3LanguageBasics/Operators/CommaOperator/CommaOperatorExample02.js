let num = (5, 1, 4, 8, 0);  // num becomes 0
