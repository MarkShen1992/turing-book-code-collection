let num1 = 1, num2 = 2, num3 = 3;
