console.log(Math.pow(3, 2);     // 9
console.log(3 ** 2);            // 9

console.log(Math.pow(16, 0.5);  // 4
console.log(16** 0.5);          // 4
