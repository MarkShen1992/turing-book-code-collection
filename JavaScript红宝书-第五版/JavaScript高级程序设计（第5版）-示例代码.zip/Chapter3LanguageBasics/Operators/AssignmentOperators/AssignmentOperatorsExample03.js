let num = 10;
num += 10;
