let num = 10;
num = num + 10;
