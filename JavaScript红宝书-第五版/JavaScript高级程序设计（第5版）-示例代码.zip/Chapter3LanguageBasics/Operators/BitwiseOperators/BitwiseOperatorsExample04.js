let num = -18;
console.log(num.toString(2));  // "-10010"
