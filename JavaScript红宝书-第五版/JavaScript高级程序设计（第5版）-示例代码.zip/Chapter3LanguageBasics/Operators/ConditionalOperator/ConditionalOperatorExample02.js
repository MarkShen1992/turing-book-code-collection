let max = (num1> num2) ? num1 : num2;
