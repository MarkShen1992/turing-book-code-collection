variable = boolean_expression ? true_value : false_value;
