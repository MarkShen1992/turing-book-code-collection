let result = "23" < 3;  // false
