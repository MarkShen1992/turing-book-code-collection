let result = "Brick".toLowerCase() < "alphabet".toLowerCase();  // false
