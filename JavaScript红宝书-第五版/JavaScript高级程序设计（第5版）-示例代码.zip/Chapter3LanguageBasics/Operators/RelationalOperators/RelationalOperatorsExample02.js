let result = "Brick" < "alphabet";  // true
