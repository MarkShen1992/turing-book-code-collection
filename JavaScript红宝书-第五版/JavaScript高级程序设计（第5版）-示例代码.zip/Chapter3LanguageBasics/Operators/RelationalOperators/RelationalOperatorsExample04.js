let result = "23" < "3";  // true
