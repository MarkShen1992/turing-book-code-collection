let result = "a" < 3;  // false because "a" becomes NaN
