let result1 = NaN < 3;   // false
let result2 = NaN>= 3;  // false
