let result1 = 5> 3;  // true
let result2 = 5 < 3;  // false
