sayHi("NicholasAlice", "how are you today?");
