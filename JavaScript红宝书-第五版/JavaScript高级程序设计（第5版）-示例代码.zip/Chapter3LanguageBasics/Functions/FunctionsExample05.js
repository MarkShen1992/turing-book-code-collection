const result = sum(5, 10);
