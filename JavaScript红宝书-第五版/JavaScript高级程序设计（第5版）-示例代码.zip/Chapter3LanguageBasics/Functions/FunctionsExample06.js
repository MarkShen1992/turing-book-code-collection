function sum(num1, num2) {
  return num1 + num2;
  console.log("Hello world");  // never executed
}
