function functionName(arg0, arg1,…,argN) {
  statements
}
