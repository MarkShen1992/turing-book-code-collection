function sayHi(name, message) {
  console.log("Hello " + name + ", " + message);
}
