let global = function() {
  return this;
}();
