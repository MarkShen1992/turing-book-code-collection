var color = "red";

function sayColor() {
  console.log(window.color);
}

window.sayColor();  // "red"
