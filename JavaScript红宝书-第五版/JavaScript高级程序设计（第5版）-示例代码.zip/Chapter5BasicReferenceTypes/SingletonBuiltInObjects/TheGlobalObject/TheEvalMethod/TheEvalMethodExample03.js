let msg = "hello world";
eval("console.log(msg)");  // "hello world"
