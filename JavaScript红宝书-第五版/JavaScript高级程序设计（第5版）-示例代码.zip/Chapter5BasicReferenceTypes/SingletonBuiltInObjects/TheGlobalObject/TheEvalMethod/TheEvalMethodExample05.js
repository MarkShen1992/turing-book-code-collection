eval("let msg = 'hello world';");
console.log(msg);  // "hello world"
