"use strict";
eval = "hi";  // causes error
