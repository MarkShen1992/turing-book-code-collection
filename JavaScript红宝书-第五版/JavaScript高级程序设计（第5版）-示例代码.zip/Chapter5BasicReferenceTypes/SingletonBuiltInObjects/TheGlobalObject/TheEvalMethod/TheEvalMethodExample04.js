eval("function sayHi() { console.log('hi'); }");
sayHi();
