let num = Math.floor(Math.random() * 10 + 1);
