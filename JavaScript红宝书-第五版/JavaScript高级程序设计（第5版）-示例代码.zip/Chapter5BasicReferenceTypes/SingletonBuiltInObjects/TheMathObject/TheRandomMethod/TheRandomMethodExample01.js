number = Math.floor(Math.random() * total_number_of_choices + first_possible_value)
