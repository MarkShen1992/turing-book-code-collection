let num = Math.floor(Math.random() * 9 + 2);
