// January 1, 2000 at midnight in local time
let y2k = new Date(2000, 0);

// May 5, 2005 at 5:55:55 PM local time
let allFives = new Date(2005, 4, 5, 17, 55, 55);
