let date1 = new Date(2019, 0, 1);    // "January 1, 2019"
let date2 = new Date(2019, 1, 1);    // "February 1, 2019"

console.log(date1 < date2);  // true
console.log(date1> date2);  // false
