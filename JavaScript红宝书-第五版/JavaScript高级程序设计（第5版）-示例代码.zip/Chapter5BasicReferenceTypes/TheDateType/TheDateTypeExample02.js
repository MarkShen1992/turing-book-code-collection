let someDate = new Date(Date.parse("May 23, 2019"));
