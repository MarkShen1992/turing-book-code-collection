let num = 10;
console.log(num.toExponential(1));  // "1.0e+1"
