let s1 = new String("some text");
let s2 = s1.substring(2);
s1 = null;
