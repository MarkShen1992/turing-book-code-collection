console.log(typeof falseObject);        // object
console.log(typeof falseValue);         // boolean
console.log(falseObject instanceof Boolean);  // true
console.log(falseValue instanceof Boolean);   // false
