let falseObject = new Boolean(false);
let result = falseObject && true;
console.log(result);  // true

let falseValue = false;
result = falseValue && true;
console.log(result);  // false
