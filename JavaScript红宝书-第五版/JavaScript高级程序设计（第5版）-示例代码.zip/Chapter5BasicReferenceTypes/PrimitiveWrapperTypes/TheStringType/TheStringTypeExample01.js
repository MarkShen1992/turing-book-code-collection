let stringObject = new String("hello world");
