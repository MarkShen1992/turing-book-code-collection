let stringValue = "hello world";
console.log(stringValue.length);   // "11"
