let stringValue = "  hello world  ";
let trimmedStringValue = stringValue.trim();
console.log(stringValue);         // "  hello world  "
console.log(trimmedStringValue);  // "hello world"
