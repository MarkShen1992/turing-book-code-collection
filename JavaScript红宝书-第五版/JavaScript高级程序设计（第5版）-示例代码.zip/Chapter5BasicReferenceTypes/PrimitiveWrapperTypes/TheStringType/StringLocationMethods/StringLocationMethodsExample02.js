let stringValue = "hello world";
console.log(stringValue.indexOf("o", 6));      // 7
console.log(stringValue.lastIndexOf("o", 6));  // 4
