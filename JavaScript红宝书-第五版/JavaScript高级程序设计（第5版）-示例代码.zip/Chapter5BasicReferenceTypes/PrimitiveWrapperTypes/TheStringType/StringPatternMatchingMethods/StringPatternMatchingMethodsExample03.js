let text = "cat, bat, sat, fat";
let pos = text.search(/at/);
console.log(pos);  // 1
