let stringValue = "hello ";
let result = stringValue.concat("world", "!");

console.log(result);       // "hello world!"
console.log(stringValue);  // "hello"
