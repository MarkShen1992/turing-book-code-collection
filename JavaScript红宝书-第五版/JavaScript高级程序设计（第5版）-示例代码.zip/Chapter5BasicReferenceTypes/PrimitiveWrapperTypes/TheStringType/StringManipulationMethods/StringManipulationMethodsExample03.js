let stringValue = "hello world";
console.log(stringValue.slice(3));        // "lo world"
console.log(stringValue.substring(3));    // "lo world"
console.log(stringValue.substr(3));       // "lo world"
console.log(stringValue.slice(3, 7));     // "lo w"
console.log(stringValue.substring(3,7));  // "lo w"
console.log(stringValue.substr(3, 7));    // "lo worl"
