for (const c of "abcde") {
  console.log(c);
}

// a
// b
// c
// d
// e
