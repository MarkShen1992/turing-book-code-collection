let message = "ab😊â¤ºde";

console.log(message.codePointAt(1));  // 98
console.log(message.codePointAt(2));  // 128522
console.log(message.codePointAt(3));  // 56842
console.log(message.codePointAt(4));  // 100
