let message = "abcde";

// Unicode "Latin small letter C" is U+0063
console.log(message.charCodeAt(2));  // 99

// Decimal 99 === Hexadecimal 63
console.log(99 === 0x63);            // true
