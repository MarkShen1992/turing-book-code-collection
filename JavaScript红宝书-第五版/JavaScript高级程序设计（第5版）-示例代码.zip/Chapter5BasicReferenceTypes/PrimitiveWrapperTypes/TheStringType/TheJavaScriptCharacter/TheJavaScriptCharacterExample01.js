let message = "abcde";

console.log(message.length);  // 5
