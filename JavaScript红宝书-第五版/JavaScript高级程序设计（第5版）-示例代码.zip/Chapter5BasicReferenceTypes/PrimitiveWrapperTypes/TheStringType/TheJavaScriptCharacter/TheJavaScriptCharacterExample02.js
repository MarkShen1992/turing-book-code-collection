let message = "abcde";

console.log(message.charAt(2));  // "c"
