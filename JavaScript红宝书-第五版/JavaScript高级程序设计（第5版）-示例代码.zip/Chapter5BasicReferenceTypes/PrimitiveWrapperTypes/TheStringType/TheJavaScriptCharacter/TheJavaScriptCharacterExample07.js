console.log([…"ab😊â¤ºde"]);  // ["a", "b", "😊â¤º", "d", "e"]
