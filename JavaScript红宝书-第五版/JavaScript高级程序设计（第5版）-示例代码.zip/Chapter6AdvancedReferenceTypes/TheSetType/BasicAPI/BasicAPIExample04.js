const s = new Set().add("val1");

s.set("val2")
 .set("val3");

alert(s.size);  // 3
