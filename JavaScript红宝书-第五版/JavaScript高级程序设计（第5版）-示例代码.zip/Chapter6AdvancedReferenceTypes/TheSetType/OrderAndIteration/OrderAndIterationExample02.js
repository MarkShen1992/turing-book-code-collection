const s = new Set(["val1", "val2", "val3"]);

alert([……s]); // [val1,val2,val3]
