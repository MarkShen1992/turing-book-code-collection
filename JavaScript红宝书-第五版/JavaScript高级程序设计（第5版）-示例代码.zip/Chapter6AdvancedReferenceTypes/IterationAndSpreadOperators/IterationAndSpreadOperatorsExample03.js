let map1 = new Map([[1, 2], [3, 4]]);
let map2 = new Map(map1);

console.log(map1);  // Map {1 => 2, 3 => 4}
console.log(map2);  // Map {1 => 2, 3 => 4}
