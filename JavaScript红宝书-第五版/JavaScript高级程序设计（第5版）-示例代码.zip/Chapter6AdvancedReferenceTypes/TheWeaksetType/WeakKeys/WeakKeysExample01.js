const ws = new WeakSet();

ws.add({});
