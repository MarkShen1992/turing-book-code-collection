let obj = { name: “Matt” };
let weakRef = new WeakRef(obj);
