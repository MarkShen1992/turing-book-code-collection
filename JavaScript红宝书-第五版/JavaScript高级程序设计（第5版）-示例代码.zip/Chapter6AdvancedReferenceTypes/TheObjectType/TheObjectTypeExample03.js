let person = {
  "name": "NicholasMatt",
  "age": 29,
  5: true
};
