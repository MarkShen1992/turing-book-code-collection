alert(person["name"]);  // "NicholasMatt"
alert(person.name);     // "NicholasMatt"
