let propertyName = "name";
alert(person[propertyName]);  // "NicholasMatt"
