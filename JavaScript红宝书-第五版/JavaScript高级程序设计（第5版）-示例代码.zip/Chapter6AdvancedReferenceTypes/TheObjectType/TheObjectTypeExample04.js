let person = {};  // same as new Object()
person.name = "NicholasMatt";
person.age = 29;
