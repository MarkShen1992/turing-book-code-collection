let person = new Object();
person.name = "NicholasMatt";
person.age = 29;
