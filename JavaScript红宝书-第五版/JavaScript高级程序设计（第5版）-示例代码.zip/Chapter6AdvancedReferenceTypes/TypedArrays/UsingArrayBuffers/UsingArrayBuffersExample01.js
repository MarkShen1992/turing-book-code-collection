const buf = new ArrayBuffer(16);  // Allocates 16 bytes of memory
alert(buf.byteLength);            // 16
