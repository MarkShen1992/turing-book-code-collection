arr.sort((a, b) => b.localeCompare(a))
["c","b","a"]
