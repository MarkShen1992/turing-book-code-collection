arr.sort((a,b) => b - a)
[3,2,1]
