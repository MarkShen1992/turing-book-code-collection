arr.sort((a, b) => a.localeCompare(b))
["a","b","c"]
