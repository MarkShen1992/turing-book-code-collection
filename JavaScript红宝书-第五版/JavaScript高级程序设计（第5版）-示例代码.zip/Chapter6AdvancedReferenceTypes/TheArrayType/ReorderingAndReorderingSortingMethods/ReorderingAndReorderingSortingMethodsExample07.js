function compare(value1, value2){
  return value2 - value1;
}
