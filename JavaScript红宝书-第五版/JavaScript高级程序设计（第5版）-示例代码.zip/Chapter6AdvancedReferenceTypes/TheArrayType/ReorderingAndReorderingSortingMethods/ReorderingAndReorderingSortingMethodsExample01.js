let values = [1, 2, 3, 4, 5];
values.reverse();
alert(values);  // 5,4,3,2,1
