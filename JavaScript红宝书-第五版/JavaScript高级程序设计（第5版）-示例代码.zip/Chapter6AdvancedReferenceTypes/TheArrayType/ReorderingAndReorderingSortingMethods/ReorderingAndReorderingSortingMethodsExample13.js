arr.sort((a, b) => a.foo.localeCompare(b.foo);
};
[{foo:"a"},{foo:"b"},{foo:"c"}]
