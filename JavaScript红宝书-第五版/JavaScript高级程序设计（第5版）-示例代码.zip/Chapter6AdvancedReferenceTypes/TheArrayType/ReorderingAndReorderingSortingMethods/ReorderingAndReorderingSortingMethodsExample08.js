arr.sort((a,b) => a - b)
[1,2,3]
