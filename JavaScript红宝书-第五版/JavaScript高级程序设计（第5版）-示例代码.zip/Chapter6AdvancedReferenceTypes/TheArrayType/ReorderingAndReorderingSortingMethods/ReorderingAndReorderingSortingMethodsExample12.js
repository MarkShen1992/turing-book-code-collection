arr.sort((a,b) => a.foo – b.foo)
[{foo: 1}, {foo: 2}, {foo: 3}]
