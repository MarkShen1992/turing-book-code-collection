let colors = new Array(20);
