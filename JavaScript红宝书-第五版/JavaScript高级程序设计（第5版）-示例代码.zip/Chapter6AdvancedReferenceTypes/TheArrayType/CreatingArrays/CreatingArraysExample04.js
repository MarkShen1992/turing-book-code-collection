let colors = new Array(3);      // create an array with three items
let names = new Array("Greg");  // create an array with one item, the string "Greg"
