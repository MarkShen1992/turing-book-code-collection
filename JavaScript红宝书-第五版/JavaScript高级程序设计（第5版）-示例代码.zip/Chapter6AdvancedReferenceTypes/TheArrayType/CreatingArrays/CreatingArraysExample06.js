let colors = ["red", "blue", "green"];  // Creates an array with three strings
let names = [];                         // Creates an empty array
let values = [1,2,];                    // Creates an array with 2 items
