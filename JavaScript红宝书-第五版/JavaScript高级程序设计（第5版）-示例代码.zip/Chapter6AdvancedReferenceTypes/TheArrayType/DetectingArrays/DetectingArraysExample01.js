if (value instanceof Array){
  // do something on the array
}
