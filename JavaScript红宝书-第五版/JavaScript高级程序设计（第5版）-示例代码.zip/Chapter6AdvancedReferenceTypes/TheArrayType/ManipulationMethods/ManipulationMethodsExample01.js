let colors = ["red", "green", "blue"];
let colors2 = colors.concat("yellow", ["black", "brown"]);

alert(colors);   // ["red", "green","blue"]
alert(colors2);  // ["red", "green", "blue", "yellow", "black", "brown"]
