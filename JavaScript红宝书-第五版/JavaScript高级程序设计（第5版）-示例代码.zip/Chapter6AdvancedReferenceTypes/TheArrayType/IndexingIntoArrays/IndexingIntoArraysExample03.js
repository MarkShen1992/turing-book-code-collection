let colors = ["red", "blue", "green"];  // creates an array with three strings
colors.length = 2;
alert(colors[2]);  // undefined
