let colors = ["red", "blue", "green"];  // creates an array with three strings
colors[99] = "black";                   // add a color (position 99)
alert(colors.length);                   // 100
