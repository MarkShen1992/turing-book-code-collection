let colors = ["red", "blue", "green"];  // define an array of strings
alert(colors[0]);                       // display the first item
colors[2] = "black";                    // change the third item
colors[3] = "brown";                    // add a fourth item
