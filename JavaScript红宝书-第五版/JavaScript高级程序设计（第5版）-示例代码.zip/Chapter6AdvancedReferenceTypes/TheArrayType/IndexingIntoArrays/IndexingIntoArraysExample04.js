let colors = ["red", "blue", "green"];  // creates an array with three strings
colors.length = 4;
alert(colors[3]);  // undefined
