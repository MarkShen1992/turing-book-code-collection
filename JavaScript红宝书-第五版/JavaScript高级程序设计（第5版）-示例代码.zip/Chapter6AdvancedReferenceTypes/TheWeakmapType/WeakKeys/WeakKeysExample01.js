const wm = new WeakMap();

wm.set({}, "val");
