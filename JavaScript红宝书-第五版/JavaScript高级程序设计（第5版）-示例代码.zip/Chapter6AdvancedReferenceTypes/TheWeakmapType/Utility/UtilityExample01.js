const m = new Map();

const loginButton = document.querySelector('#login');

// Associates some metadata with the node
m.set(loginButton, {disabled: true});
