console.log(typeof Array.prototype.sort);        // "function"
console.log(typeof String.prototype.substring);  // "function"
