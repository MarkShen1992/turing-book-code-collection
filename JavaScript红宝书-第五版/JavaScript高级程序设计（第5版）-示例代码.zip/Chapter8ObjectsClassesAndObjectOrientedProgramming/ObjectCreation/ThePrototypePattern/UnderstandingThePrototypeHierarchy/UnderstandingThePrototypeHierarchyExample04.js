person.hasOwnProperty("name");
Object.hasOwn(person, "name"); 
 HYPERLINK "" \l "c08-fig-anc-0002" Figure 8.2Figure 8.2[c08f002.eps] [AU: Okay that “Nicholas” is in the figure?]
Figure 8.2: diagram showing the effects of assignment and delete operations


