console.log(person1 !== Person);            
// true

console.log(person1 !== Person.prototype);  
// true

console.log(Person.prototype !== Person);   
// true
