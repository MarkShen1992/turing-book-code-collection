let person1 = new Person(),
    person2 = new Person();
