console.log(Person.prototype.constructor === Person);  
// true
