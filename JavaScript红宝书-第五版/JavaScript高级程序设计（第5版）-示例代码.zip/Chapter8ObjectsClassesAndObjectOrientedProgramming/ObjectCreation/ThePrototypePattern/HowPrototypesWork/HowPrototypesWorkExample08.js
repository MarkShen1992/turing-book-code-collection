console.log(person1.__proto__ === person2.__proto__);  
// true
