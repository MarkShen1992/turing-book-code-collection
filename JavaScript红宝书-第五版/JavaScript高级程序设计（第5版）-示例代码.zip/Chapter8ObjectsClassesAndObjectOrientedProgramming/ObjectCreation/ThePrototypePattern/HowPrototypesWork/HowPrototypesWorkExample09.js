console.log(person1 instanceof Person);  
// true

console.log(person1 instanceof Object);  
// true

console.log(Person.prototype instanceof Object);  
// true
