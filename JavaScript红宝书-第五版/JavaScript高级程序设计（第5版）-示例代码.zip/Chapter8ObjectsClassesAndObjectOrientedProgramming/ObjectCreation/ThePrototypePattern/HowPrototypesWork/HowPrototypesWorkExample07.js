Console.log(person1.__proto__ === Person.prototype);    
// true

conosle.log(person1.__proto__.constructor === Person);  
// true
