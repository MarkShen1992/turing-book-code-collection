console.log(person1.sayName == person2.sayName);  // false
