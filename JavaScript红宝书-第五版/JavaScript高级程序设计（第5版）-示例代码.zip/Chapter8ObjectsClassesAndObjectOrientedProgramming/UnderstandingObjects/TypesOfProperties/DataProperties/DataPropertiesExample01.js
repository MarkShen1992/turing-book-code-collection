let person = {
  name: "NicholasAlice"
};
