let person = {
  sayName: function(name) {
    console.log('My name is ${name}');
  }
};

person.sayName('Matt');  // My name is Matt
