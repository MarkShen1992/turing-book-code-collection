let name = 'Matt';

let person = {
  name: name
};

console.log(person);  // { name: 'Matt' }
