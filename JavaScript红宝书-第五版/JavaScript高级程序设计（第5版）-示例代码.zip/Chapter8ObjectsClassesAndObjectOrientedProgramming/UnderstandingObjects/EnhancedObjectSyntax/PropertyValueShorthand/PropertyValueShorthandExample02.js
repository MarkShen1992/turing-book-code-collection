let name = 'Matt';

let person = {
  name
};

console.log(person);  // { name: 'Matt' }
