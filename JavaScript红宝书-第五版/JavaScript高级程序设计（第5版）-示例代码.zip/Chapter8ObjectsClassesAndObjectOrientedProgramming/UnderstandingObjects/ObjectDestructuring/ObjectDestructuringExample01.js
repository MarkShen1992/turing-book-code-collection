// Without object destructuring
let person = {
  name: 'Matt',
  age: 27
};

let personName = person.name,
    personAge = person.age;

console.log(personName);  // Matt
console.log(personAge);   // 27
