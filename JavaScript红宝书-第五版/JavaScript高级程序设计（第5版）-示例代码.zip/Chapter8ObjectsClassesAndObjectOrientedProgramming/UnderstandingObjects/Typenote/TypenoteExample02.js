console.log(person["name"]);  // Alice
console.log(person["age"]);   // 30
