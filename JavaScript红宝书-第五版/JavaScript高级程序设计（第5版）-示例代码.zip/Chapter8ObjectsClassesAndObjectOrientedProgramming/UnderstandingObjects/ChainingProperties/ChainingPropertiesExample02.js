const person = { ... };
const address = person.address;
console.log(address.city);  // Chicago
