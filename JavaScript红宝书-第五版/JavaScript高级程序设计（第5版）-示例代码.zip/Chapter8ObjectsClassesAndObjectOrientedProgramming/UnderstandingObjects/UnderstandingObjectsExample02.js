let person = {
  name: "NicholasAlice",
  age: 29,
  job: "Software Engineer",
  sayName() {
    console.log(this.name);
  }
};
