class Person {
  name: 'Jake'
}
// Uncaught SyntaxError: Unexpected token :
