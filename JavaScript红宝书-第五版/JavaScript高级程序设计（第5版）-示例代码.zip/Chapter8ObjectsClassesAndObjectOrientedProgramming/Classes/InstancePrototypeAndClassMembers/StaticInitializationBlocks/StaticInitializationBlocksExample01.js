class Person {
  static name = "Alice";
  static age;
  static {
    this.age = 30;
  }
}
