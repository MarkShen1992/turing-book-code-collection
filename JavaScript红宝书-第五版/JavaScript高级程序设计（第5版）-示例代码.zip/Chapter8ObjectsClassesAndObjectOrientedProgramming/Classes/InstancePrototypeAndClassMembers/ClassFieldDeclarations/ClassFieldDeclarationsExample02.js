class Person {
  friendCount = 0;

  constructor() {
    console.log(this.friendCount);  // 0
  }
}
