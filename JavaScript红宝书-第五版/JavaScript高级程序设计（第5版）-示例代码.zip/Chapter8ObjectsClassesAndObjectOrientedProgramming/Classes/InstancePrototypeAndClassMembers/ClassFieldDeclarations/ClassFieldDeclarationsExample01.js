class PersonWithConstructor {
  constructor() {
    this.friendCount = 0;
  }
}

class PersonWithClassFields {
  friendCount = 0;
}
