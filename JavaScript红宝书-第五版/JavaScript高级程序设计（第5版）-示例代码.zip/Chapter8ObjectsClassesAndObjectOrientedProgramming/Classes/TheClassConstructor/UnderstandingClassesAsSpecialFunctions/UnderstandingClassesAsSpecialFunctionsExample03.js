class Person {}

let p = new Person();

console.log(p instanceof Person);  // true
