class Person {}

console.log(Person);         // class Person {}
console.log(typeof Person);  // function
