// class declaration
class Person {}

// class expression
const Animal = class {};
