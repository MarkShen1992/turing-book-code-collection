let name = 'Jake';
setInterval(() => {
  console.log(name);
}, 100);
