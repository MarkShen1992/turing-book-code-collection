function setName() {
  name = 'Jake';
}
