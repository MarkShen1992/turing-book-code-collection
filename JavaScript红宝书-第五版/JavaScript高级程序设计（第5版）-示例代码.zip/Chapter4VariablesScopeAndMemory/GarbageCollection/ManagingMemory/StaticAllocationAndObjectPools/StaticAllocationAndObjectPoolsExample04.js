let vectorList = new Array(100);
let vector = new Vector();
vectorList.push(vector);
