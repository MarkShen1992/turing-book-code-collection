let person = new Object();
person.name = "NicholasAlice";
console.log(person.name);  // "NicholasAlice"
