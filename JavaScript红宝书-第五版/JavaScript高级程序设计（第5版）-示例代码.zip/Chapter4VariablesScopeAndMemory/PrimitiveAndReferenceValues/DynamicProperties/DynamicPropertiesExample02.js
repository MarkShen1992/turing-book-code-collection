let name = "NicholasAlice";
name.age = 27;
console.log(name.age);  // undefined
