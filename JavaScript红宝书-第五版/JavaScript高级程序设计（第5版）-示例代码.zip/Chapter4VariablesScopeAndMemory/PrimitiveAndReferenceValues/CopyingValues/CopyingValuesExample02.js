let obj1 = new Object();
let obj2 = obj1;
obj1.name = "NicholasAlice";
console.log(obj2.name);  // "NicholasAlice"
