let num1 = 5;
let num2 = num1;
