let s = "NicholasAlice";
let b = true;
let i = 22;
let u;
let n = null;
let o = new Object();

console.log(typeof s);   // string
console.log(typeof i);   // number
console.log(typeof b);   // boolean
console.log(typeof u);   // undefined
console.log(typeof n);   // object
console.log(typeof o);   // object
