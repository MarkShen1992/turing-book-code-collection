result = variable instanceof constructor
