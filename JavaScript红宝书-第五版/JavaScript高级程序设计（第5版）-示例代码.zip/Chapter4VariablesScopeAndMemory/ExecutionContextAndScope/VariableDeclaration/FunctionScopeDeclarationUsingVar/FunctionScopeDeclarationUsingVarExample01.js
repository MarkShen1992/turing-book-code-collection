function add(num1, num2) {
  var sum = num1 + num2;
  return sum;
}

let result = add(10, 20);  // 30
console.log(sum);          // causes an error: sum is not a valid variable
