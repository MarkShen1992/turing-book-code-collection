var name = "Jake";

// This is equivalent to:

name = 'Jake';
var name;
