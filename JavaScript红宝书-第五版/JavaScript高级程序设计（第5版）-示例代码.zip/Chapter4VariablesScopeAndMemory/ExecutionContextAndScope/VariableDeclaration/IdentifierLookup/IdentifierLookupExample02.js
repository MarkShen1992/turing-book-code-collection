var color = 'blue';

function getColor() {
  let color = 'red';
  return color;
}

console.log(getColor());  // 'red'
