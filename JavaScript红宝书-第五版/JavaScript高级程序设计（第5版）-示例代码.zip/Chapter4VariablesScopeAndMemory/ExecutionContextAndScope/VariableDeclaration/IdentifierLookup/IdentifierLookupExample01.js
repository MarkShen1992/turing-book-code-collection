var color = 'blue';

function getColor() {
  return color;
}

console.log(getColor());  // 'blue'
