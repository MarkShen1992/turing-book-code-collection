const o3 = Object.freeze({});
o3.name = 'Jake';
console.log(o3.name);  // undefined
