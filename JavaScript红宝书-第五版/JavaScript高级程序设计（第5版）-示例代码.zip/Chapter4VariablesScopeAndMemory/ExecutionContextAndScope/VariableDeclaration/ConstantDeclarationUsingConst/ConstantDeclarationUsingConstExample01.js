const a;  // SyntaxError: Missing initializer in const declaration

const b = 3;
console.log(b);  // 3
b = 4;  // TypeError: Assignment to a constant variable
