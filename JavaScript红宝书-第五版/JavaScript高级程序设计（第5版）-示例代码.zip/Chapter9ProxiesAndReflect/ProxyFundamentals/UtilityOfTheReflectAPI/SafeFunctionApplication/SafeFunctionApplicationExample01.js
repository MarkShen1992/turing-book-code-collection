Function.prototype.apply.call(myFunc, thisVal, argumentList);
